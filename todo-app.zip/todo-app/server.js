
//endpoint pour ajouter une tache
app.post('/todos', (req, res) => {

    // Récupérer les données de la nouvelle tâche depuis le corps de la requête
    const { title, description, priority } = req.body;
    
    // Générer un nouvel ID pour la tâche
    const id = tasks.length + 1;
    
    // Créer un objet représentant la nouvelle tâche
    const newTask = {
        id,
        title,
        description,
        createdAt: new Date(),
        finishedAt: null,
        finished: false,
        priority
    };
    
    // Ajouter la nouvelle tâche à la liste des tâches
    tasks.push(newTask);
    
    // Répondre avec la nouvelle tâche ajoutée
    res.status(201).json(newTask);
});

// endpoint pour modifier une tache
app.put('/todos/:id', (req, res) => {
    // Récupérer l'ID de la tâche à modifier depuis les paramètres de l'URL
    const taskId = parseInt(req.params.id);
    
    // Récupérer les nouvelles données de la tâche depuis le corps de la requête
    const { title, description, priority } = req.body;
    
    // Trouver la tâche à modifier dans la liste des tâches
    const taskToUpdate = tasks.find(task => task.id === taskId);
    
    // Mettre à jour les propriétés de la tâche si elle existe
    if (taskToUpdate) {
        taskToUpdate.title = title;
        taskToUpdate.description = description;
        taskToUpdate.priority = priority;
        
        // Répondre avec la tâche mise à jour
        res.json(taskToUpdate);
    } else {
        // Si la tâche n'est pas trouvée, retourner une erreur 404
        res.status(404).json({ message: "Tâche non trouvée" });
    }
});

// endpoint pour Afficher la liste de toutes les tâches (id, title,priority, createdAt, finished)
app.get('/todos', (req, res) => {
    // Renvoyer la liste complète des tâches
    res.json(tasks);
});

//endppoint pour Afficher les détails d’une tâche à partir de son id
app.get('/todos/:id', (req, res) => {
    // Récupérer l'ID de la tâche depuis les paramètres de l'URL
    const taskId = parseInt(req.params.id);
    
    // Trouver la tâche dans la liste des tâches
    const task = tasks.find(task => task.id === taskId);
    
    // Répondre avec les détails de la tâche si elle existe
    if (task) {
        res.json(task);
    } else {
        // Si la tâche n'est pas trouvée, retourner une erreur 404
        res.status(404).json({ message: "Tâche non trouvée" });
    }
});

//endpoint pour Supprimer une tâche à partir de son id
app.delete('/todos/:id', (req, res) => {
    // Récupérer l'ID de la tâche à supprimer depuis les paramètres de l'URL
    const taskId = parseInt(req.params.id);
    
    // Trouver l'index de la tâche dans la liste des tâches
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    
    // Supprimer la tâche si elle existe
    if (taskIndex !== -1) {
        tasks.splice(taskIndex, 1);
        res.status(204).end();
    } else {
        // Si la tâche n'est pas trouvée, retourner une erreur 404
        res.status(404).json({ message: "Tâche non trouvée" });
    }
});

//Filtrer les tâches par leur titre via un paramètre nommé « search »
app.get('/todos/order', (req, res) => {
    // Trier les tâches par ordre de priorité (ordre croissant)
    const orderedTasks = tasks.sort((a, b) => a.priority - b.priority);
    
    // Répondre avec la liste triée des tâches
    res.json(orderedTasks);
});

//Trier les tâches par ordre de priorité Pour toute autre api, retourner une erreur 404
app.use((req, res) => {
    res.status(404).json({ message: "Ressource non trouvée" });
});
