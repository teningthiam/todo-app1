let tasks = [
    {
        // ma premiere tâche
        id: 1,
        title: "Faire les courses",
        description: "Acheter des fruits et légumes pour la semaine",
        createdAt: new Date(),
        finishedAt: null,
        finished: false,
        priority: 2
    },
    //ma seconde tâche
    {
        id: 2,
        title: "Réviser pour l'examen",
        description: "Réviser les chapitres 1 à 5 pour l'examen de javascript",
        createdAt: new Date(),
        finishedAt: null,
        finished: false,
        priority: 1
    },
    // troisieme tache
    {
        id: 3,
        title: "Faire du sport",
        description: "Faire 30 minutes de course à pied",
        createdAt: new Date(),
        finishedAt: null,
        finished: false,
        priority: 3
    },
    //quatrieme tache
    {
        id: 4,
        title: "Répondre aux e-mails",
        description: "Répondre à tous les e-mails en attente dans la boîte de réception",
        createdAt: new Date(),
        finishedAt: null,
        finished: false,
        priority: 4
    },
    //quatrieme tache
    {
        id: 5,
        title: "Préparer le dîner",
        description: "Cuisiner un repas sain et équilibré pour ce soir",
        createdAt: new Date(),
        finishedAt: null,
        finished: false,
        priority: 5
    }
    
    

  ];
  module.exports = tasks;